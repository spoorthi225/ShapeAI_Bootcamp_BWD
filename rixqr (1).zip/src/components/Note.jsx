import React from "react";

function Note() {
  return (
    <div>
      <p>
        the{" "}
        <u>
          <i>Marvel cinematic universe</i>
        </u>
        is an american media franchies and shared universe centered on a series
        of <b>superhero films</b> produced by <b>Marvel</b> studios.The{" "}
        <b>films</b> are based on characters that appear in American comic books
        published by <b>Marvel</b> comics.
      </p>
    </div>
  );
}

export default Note;
